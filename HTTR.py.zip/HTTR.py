print("این رو برای اختیاری انجام دادم و توش از *args و *kwargs استفاده کردم")
def hrrn(*args, **kwargs):
    """
    الگوریتم HRRN (Highest Response Ratio Next)
    Response Ratio = (Waiting Time + Service Time) / Service Time
    
    استفاده:
    1. با لیست: hrrn(processes_list)
    2. با kwargs: hrrn(show_gantt=True, sort_by='Arrival')
    3. ترکیبی: hrrn(processes_list, show_gantt=True)
    """
    # پارامترهای پیش‌فرض
    show_gantt = kwargs.get('show_gantt', True)
    sort_by = kwargs.get('sort_by', 'Arrival')
    show_averages = kwargs.get('show_averages', True)
    
    # دریافت لیست فرآیندها
    if args:
        processes = args[0]
    elif 'processes' in kwargs:
        processes = kwargs['processes']
    else:
        return "خطا: لیست فرآیندها را وارد کنید"
    
    n = len(processes)
    completed = [False] * n
    time = 0
    done = 0
    results = []
    
    while done < n:
        idx = -1
        highest_rr = -1
        
        for i in range(n):
            if not completed[i] and processes[i]['Arrival'] <= time:
                wait = time - processes[i]['Arrival']
                response_ratio = (wait + processes[i]['Service']) / processes[i]['Service']
                
                if response_ratio > highest_rr:
                    highest_rr = response_ratio
                    idx = i
        
        if idx == -1:
            time += 1
        else:
            p = processes[idx]
            start = time
            end = time + p['Service']
            
            results.append({
                'PID': p['PID'],
                'Arrival': p['Arrival'],
                'Service': p['Service'],
                'Start': start,
                'End': end,
                'Waiting': start - p['Arrival']
            })
            
            time = end
            completed[idx] = True
            done += 1
    
    # مرتب‌سازی
    if sort_by == 'Arrival':
        results.sort(key=lambda x: x['Arrival'])
    elif sort_by == 'PID':
        results.sort(key=lambda x: x['PID'])
    elif sort_by == 'Start':
        results.sort(key=lambda x: x['Start'])
    
    # نمایش نتایج
    print("\n" + "="*70)
    print(f"{'PID':<8} {'Arrival':<10} {'Service':<10} {'Start':<8} {'End':<8} {'Waiting':<10}")
    print("="*70)
    
    total_wait = 0
    total_turnaround = 0
    
    for r in results:
        print(f"{r['PID']:<8} {r['Arrival']:<10} {r['Service']:<10} {r['Start']:<8} {r['End']:<8} {r['Waiting']:<10}")
        total_wait += r['Waiting']
        total_turnaround += (r['End'] - r['Arrival'])
    
    print("="*70)
    
    if show_averages:
        print(f"میانگین زمان انتظار: {total_wait/n:.2f}")
        print(f"میانگین زمان برگشت: {total_turnaround/n:.2f}")
        print("="*70)
    
    # نمودار گانت
    if show_gantt:
        print("\nنمودار گانت:")
        print("="*70)
        
        gantt_order = sorted(results, key=lambda x: x['Start'])
        
        for r in gantt_order:
            spaces = " " * (r['Start'] * 2)
            blocks = "█" * (r['Service'] * 2)
            print(f"{r['PID']:<6} {spaces}{blocks} [{r['Start']}-{r['End']}]")
        
        print("="*70)
    
    return results


def get_input():
    """دریافت ورودی از کاربر"""
    print("چند فرآیند دارید؟")
    n = int(input())
    
    processes = []
    for i in range(n):
        print(f"\nفرآیند {i+1}:")
        pid = input("PID: ")
        arrival = int(input("Arrival Time: "))
        service = int(input("Service Time: "))
        
        processes.append({
            'PID': pid,
            'Arrival': arrival,
            'Service': service
        })
    
    return processes


# مثال استفاده
if __name__ == "__main__":
    # روش 1: ورودی از کاربر
    processes = get_input()
    hrrn(processes)
    
    # روش 2: با kwargs
    # hrrn(processes, show_gantt=True, sort_by='Arrival', show_averages=True)
    
    # روش 3: داده‌های از پیش تعریف شده
    # sample_data = [
    #     {'PID': 'P1', 'Arrival': 0, 'Service': 3},
    #     {'PID': 'P2', 'Arrival': 2, 'Service': 6},
    #     {'PID': 'P3', 'Arrival': 4, 'Service': 4},
    # ]
    # hrrn(sample_data, show_gantt=False, sort_by='PID')
